

const menuToggle = document.getElementById("menuToggle");
const navigation = document.getElementById("navigation");

if (menuToggle && navigation) {

    menuToggle.addEventListener("click", () => {

        const aberto = navigation.classList.toggle("open");

        menuToggle.setAttribute("aria-expanded", aberto);

    });
    navigation.querySelectorAll("a").forEach(link => {

        link.addEventListener("click", () => {

            navigation.classList.remove("open");

            menuToggle.setAttribute("aria-expanded", "false");

        });

    });

}



/* =========================================
   CALCULADORA DE DESPERDÍCIO
========================================= */

const wastedItems = document.getElementById("wastedItems");
const people = document.getElementById("people");

const itemsValue = document.getElementById("itemsValue");
const peopleValue = document.getElementById("peopleValue");

const yearlyWaste = document.getElementById("yearlyWaste");
const perPerson = document.getElementById("perPerson");

const comparisonBar = document.getElementById("comparisonBar");
const savingTip = document.getElementById("savingTip");


function atualizarCalculadora() {

    if (!wastedItems || !people) return;

    const itens = Number(wastedItems.value);
    const pessoas = Number(people.value);
    const desperdicioAnual = itens * 0.4 * 52;
    const desperdicioPessoa = desperdicioAnual / pessoas;
    const economia = desperdicioAnual / 2;
    // Atualização dos valores

    itemsValue.textContent = itens;
    peopleValue.textContent = pessoas;
    yearlyWaste.textContent = Math.round(desperdicioAnual);
    perPerson.textContent =
        desperdicioPessoa.toFixed(1).replace(".", ",") + " kg";
    const porcentagem = Math.min(
        (desperdicioAnual / 128) * 100,
        100
    );

    comparisonBar.style.width = porcentagem + "%";
    savingTip.textContent =
        `Evitando metade do desperdício, sua casa deixaria de jogar fora aproximadamente ${economia.toFixed(1).replace(".", ",")} kg por ano.`;

}

if (wastedItems && people) {
    wastedItems.addEventListener("input", atualizarCalculadora);
    people.addEventListener("input", atualizarCalculadora);
    atualizarCalculadora();

}

/* =========================================
   FORMULÁRIO DO APLICATIVO
========================================= */
const appForm = document.getElementById("appForm");
const appEmail = document.getElementById("appEmail");
const appFeedback = document.getElementById("appFeedback");
if (appForm) {
    appForm.addEventListener("submit", (event) => {
        event.preventDefault();

        if (!appEmail.reportValidity()) return;

        appFeedback.textContent =
            "E-mail preenchido! Configure o serviço de envio para registrar seu interesse no lançamento.";

        appFeedback.style.color = "#f6c62f";

        // Não simula um cadastro concluído.
        // O envio real precisa de um serviço de e-mail
        // ou de um backend.

    });

}
